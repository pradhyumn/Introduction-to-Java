
public class Dog {
        private int age;
        private String owner;
        private String breed;
        
        public static void main(String[] args) {
                
                Dog[] dogs = new Dog[5];
                dogs[0] = new Dog(4, "Stephen Colbert", "Boxer");
                
        }
}