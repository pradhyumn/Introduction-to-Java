
public class SquarePyramid {
	
}
