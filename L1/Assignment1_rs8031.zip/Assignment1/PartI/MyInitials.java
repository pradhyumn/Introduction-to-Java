
public class MyInitials {

	public static void main(String[] args) {
		System.out.println("RRRR    SSS    SSS ");
		System.out.println("R   R  S   S  S   S");
		System.out.println("R   R  S      S    ");
		System.out.println("RRRR    SSS    SSS ");
		System.out.println("R R        S      S");
		System.out.println("R  R   S   S  S   S");
		System.out.println("R   R   SSS    SSS ");
	}
}
