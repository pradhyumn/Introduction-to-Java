package vehicles;


public class VehicleException extends Exception {
	//  TODO: Figure out why this warning?
	private static final long serialVersionUID = 1L;

	public VehicleException(String errorMsg) {
		super(errorMsg);
	}

}
