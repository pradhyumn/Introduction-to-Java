
public class Literals {

	public static void main(String[] args) {
		
		int intLiteral = 2147483647;
		double doubleLiteral = 1.23456e2;
	}
}
